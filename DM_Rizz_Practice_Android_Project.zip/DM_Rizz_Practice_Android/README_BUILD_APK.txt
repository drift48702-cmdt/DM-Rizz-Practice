DM RIZZ PRACTICE — Android Studio project

This is an Android WebView wrapper around the included practice app. It is source code, not a precompiled APK: this environment does not have the Android SDK or Gradle installed, so no APK has been built or signed here.

BUILD AN APK
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. In Android Studio choose Open, then select the extracted `DM_Rizz_Practice_Android` folder.
4. Let Android Studio sync/download the Android Gradle plugin and SDK components.
5. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
6. When the build completes, use the notification's `locate` link. The debug APK is typically under `app/build/outputs/apk/debug/app-debug.apk`.
7. Transfer the APK to your Android phone and open it to install. Android may ask you to allow installs from that file manager.

FEATURES
- Offline practice scenarios, personalities, difficulty settings, slang notes and feedback.
- Auto mode falls back to offline practice when online AI is unavailable.
- Optional online AI mode requires a compatible API endpoint and API key.

ONLINE AI NOTE
The sample online request uses an OpenAI-compatible Chat Completions endpoint. Some providers may block requests from WebView/file origins or use a different response format. If so, a secure backend proxy or provider-specific integration is needed. Avoid distributing an app with a personal API key embedded. This starter stores the key in local app web storage if you save settings; for a public app, move AI requests to a secure backend.

No APK is attached because no Android SDK/build system was available in this environment. The ZIP contains the Android Studio project needed to build one.
